#include<stdio.h>
main(){
    int first=0,second=1,third,n,i=1;
    
    printf("enter any number:");
    scanf("%d",&n);




    for(i=3;i<=n;i++){

        printf("%d ",third);

        first=second;
        second=third;
        third=first+second;
    }
}