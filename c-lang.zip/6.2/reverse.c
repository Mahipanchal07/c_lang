#include<stdio.h>
main(){
    int i;
    for(i=10;i>=1;i--)
    {
        printf("%d ",i);
    }
}