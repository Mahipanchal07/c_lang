#include<stdio.h>
int main()
{
  int i=65;
 do
 {
   printf("%c ",i);
  i=+4;
 }
  while(i<=90);

  return 0;

}