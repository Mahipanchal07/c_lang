#include<stdio.h>
main(){
	printf("Name: Mahi Panchal \n");
	printf("Age:18 \n");
	printf("Institute name: Red & White \n");
	
}
