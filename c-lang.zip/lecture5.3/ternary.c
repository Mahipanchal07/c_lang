#include<stdio.h>
main(){
    int a,b,sum;

    printf("enter number:");
    scanf("%d",&a);

    printf("enter number:");
    scanf("%d",&b);

    sum=a<b? a:b;

    printf("Minimum value is: %d",sum);
}