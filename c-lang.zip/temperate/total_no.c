#include<stdio.h>
main(){
    int no,a=0;

    printf("Enter any number:");
    scanf("%d",&no);
   
   while(no>=1){
    no = no/10;
    a++;
   }
   printf("digit of number is: %d",a);

}