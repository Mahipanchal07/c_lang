#include<stdio.h>
main(){
    int n=1,i;

    printf("entr the number:");
    scanf("%d",&i);
while (n<=i)
{
    printf("%d ",n);
    n++;
}

}