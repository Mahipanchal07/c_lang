#include<stdio.h>
main(){
    int n1,n2,n3;

    printf("Enter the value of N1:");
    scanf("%d",&n1);

    printf("Enter the value of N2:");
    scanf("%d",&n2);

    printf("Enter the value of N3:");
    scanf("%d",&n3);

    if(n1<n2 && n1<n3){
        if(n2<n1 && n2<n3){
            printf("Minimum number is : %d",n2);
        }
        else{
            printf("Minimum number is :%d",n1);
        }        
    }
    else{
        printf("Minimum number is %d",n3);
    }

}