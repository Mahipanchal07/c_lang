#include<stdio.h>
main()
{
	int c,f;
	printf("enter the value of `c");
	scanf("%d",&c);
	
	f=(c*9/5)+32;
	
	printf("the tempreture in feranhit is:%d",f);
}