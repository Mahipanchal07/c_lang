#include <stdio.h>
void main() {
	
   int pie = 3.14;
   int r,area ;
   
   printf("enter value of r:");
   scanf("%d",&r);
   
   area=pie*r*r;
   
   printf("The area of the circle is %d " , area);
}
