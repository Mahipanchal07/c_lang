#include<Stdio.h>
main(){
    int n;

    printf("Enter Number:");
    scanf("%d",&n);

    for(int i=1;i<=10;i++)
    {
        printf("%d * %d = %d \n",n,i,n*i);
    }
    
}