#include<stdio.h>
main(){
	
	
	
}
