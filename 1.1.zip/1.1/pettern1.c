#include<stdio.h>
main(){
	
	printf(" -------- \n |      |\n R      |\n N      |\n W      |\n |      |\n --------\n");
	
}
