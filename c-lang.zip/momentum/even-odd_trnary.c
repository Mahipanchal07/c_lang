#include<stdio.h>
main(){
    int a,sum;

    printf("enter number:");
    scanf("%d",&a);

    sum=(a%2==0) ?  printf("even number "): printf("odd number");
  
}