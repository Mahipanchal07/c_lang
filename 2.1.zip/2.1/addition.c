#include<stdio.h>
void main(){
    int a,b;

    printf("enter value of A:");
    scanf("%d",&a);

    printf("enter value of B:");
    scanf("%d",&b);


    printf("Addition is %d " ,a+b);
}