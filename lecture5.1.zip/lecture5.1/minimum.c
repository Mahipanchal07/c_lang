#include<stdio.h>
void main(){
    int a,b;

    printf("Enter value of A:");
    scanf("%d",&a);

    printf("Enter value of B:");
    scanf("%d",&b);

    if(a>b){
        printf("minimunnum is: %d",b);
    }
    else{
        printf("minimum num is: %d",a);
    }

}