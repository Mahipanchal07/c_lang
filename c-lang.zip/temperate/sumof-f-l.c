#include<stdio.h>
main(){
    int no,fd,ld,sum=0;

    printf("Enter any number:");
    scanf("%d",&no);

    ld=no%10;
     while(no >= 10)
     {
     no = no / 10;
     }
     fd= no;
     sum = fd + ld;  
    
    printf("sum of first and last digit is: %d",sum);
}