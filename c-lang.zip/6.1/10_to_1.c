#include<stdio.h>
main(){
    int n=10;

while (n>=1)
{
    printf("%d ",n);
    n--;
}

}