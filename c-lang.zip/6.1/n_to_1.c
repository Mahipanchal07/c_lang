#include<stdio.h>
main(){
    int i,n;

    printf("entr the number:");
    scanf("%d",&n);
    i=n;
while (i>=1)
{
    if(n%2!=0)
    {
        printf("%d ",i);
    }
    i--;
}
}