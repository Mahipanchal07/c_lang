#include<stdio.h>
void main(){
    int n;

    printf("Enter the value:");
    scanf("%d",&n);

    if(n>0){
        printf("this number is positive");
    }
    else if(n==0){
        printf("this number is natural");
    }
    else{
        printf("this number is negative");
    }
}